import"../devtools_app/devtools_app.js";
import*as e from"../../ui/legacy/legacy.js";
e.ContextMenu.registerItem({location:e.ContextMenu.ItemLocation.MAIN_MENU,order:10,actionId:"components.request-app-banner"});
